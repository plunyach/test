// import "../styles/trackOrderProgressBar.css"

// import React from "react";
// import {
//   MDBCard,
//   MDBCardBody,
//   MDBCol,
//   MDBContainer,
//   MDBRow,
// } from "mdb-react-ui-kit";

// export default function OrderDetails5() {
//   return (
//     <>
//       <section className="vh-100 gradient-custom-2">
//         <MDBContainer className="py-5 h-100">
//           <MDBRow className="justify-content-center align-items-center h-100">
//             <MDBCol md="10" lg="8" xl="6">
//               <MDBCard
//                 className="card-stepper"
//                 style={{ borderRadius: "16px" }}
//               >
                
//                 <MDBCardBody className="p-4">
                  
//                   <ul
//                     id="progressbar-1"
//                     className="mx-0 mt-0 mb-5 px-0 pt-0 pb-4"
//                   >
//                     <li className="step0 active" id="step1">
//                       <span style={{ marginLeft: "22px", marginTop: "12px" }}>
//                         PLACED
//                       </span>
//                     </li>
//                     <li className="step0 active text-center" id="step2">
//                       <span>SHIPPED</span>
//                     </li>
//                     <li className="step0 text-muted text-end" id="step3">
//                       <span style={{ marginRight: "22px" }}>DELIVERED</span>
//                     </li>
//                   </ul>
//                 </MDBCardBody>
//               </MDBCard>
//             </MDBCol>
//           </MDBRow>
//         </MDBContainer>
//       </section>
//     </>
//   );
// }