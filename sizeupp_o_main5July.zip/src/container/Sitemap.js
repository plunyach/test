
import '../styles/sitemap.css';
import React from 'react'
import ToolBar from '../component/toolbar'
import { Footer } from './footer'

export default function Sitemap() {
  return (
    <div>
        <ToolBar fontColor="#474747" logo="black" dropDown="#474747" icons="#474747" backGroundColor="white" stroke="black" />
        <div className='sm-main-container'>
            <div className='sm-container'>
                <h2>sitemap</h2>

                <div className='sm-text-container'>
                <p className='sm-heading'>lorem ipsum</p>
                <p className='sm-content'>
                lörem ipsum mytotropi grexit, krosk trehös. Rarade syde sakavis i krohyrad hemining. Divade. 
                lörem ipsum mytotropi grexit, krosk trehös. Rarade syde sakavis i krohyrad hemining. Divade.lörem 
                ipsum mytotropi grexit, krosk trehös. Rarade syde sakavis i krohyrad hemining. Divade. lörem ipsum mytotropi
                 grexit, krosk trehös. Rarade syde sakavis i krohyrad hemining. Divade. lörem ipsum mytotropi grexit, krosk trehös. 
                 Rarade syde sakavis i krohyrad hemining. Divade. lörem ipsum mytotropi grexit, krosk trehös. Rarade syde sakavis 
                 i krohyrad hemining. Divade.lörem ipsum mytotropi grexit, krosk trehös. Rarade syde sakavis 
                i krohyrad hemining. Divade. lörem ipsum mytotropi grexit, krosk trehös. Rarade syde sakavis i krohyrad hemining. 
                Divade.
                </p>
                </div>

                <div className='sm-text-container'>
                <p className='sm-heading'>lorem ipsum</p>
                <p className='sm-content'>
                lörem ipsum mytotropi grexit, krosk trehös. Rarade syde sakavis i krohyrad hemining. Divade. 
                lörem ipsum mytotropi grexit, krosk trehös. Rarade syde sakavis i krohyrad hemining. Divade.lörem 
                ipsum mytotropi grexit, krosk trehös. Rarade syde sakavis i krohyrad hemining. Divade. lörem ipsum 
                mytotropi grexit, krosk trehös. Rarade syde sakavis i krohyrad hemining. Divade. lörem ipsum mytotropi 
                grexit, krosk trehös. Rarade syde sakavis i krohyrad hemining. Divade. lörem ipsum mytotropi grexit, 
                krosk trehös. Rarade syde sakavis i krohyrad hemining. Divade.lörem ipsum mytotropi grexit, krosk trehös. 
                Rarade syde sakavis i krohyrad hemining. Divade. lörem ipsum mytotropi grexit, krosk trehös. Rarade syde
                 sakavis i krohyrad hemining. Divade. lörem ipsum mytotropi grexit, krosk trehös. Rarade syde sakavis i
                  krohyrad hemining. Divade. lörem ipsum mytotropi grexit, krosk trehös. Rarade syde sakavis i krohyrad 
                  hemining. Divade.lörem ipsum mytotropi grexit, krosk trehös. Rarade syde sakavis i krohyrad hemining. 
                  Divade. lörem ipsum mytotropi grexit, krosk trehös. Rarade syde sakavis i krohyrad hemining. Divade. 
                  lörem ipsum mytotropi grexit, krosk trehös. Rarade syde sakavis i krohyrad hemining. Divade. lörem 
                  ipsum mytotropi grexit, krosk trehös. Rarade syde sakavis i krohyrad hemining. Divade.lörem ipsum mytotropi 
                  grexit, krosk trehös. Rarade syde sakavis i krohyrad hemining. 
                Divade. lörem ipsum mytotropi grexit, krosk trehös. Rarade syde sakavis i krohyrad hemining. Divade.
                </p>
                </div>

                <div className='sm-text-container'>
                <p className='sm-heading'>lorem ipsum</p>
                <p className='sm-content'>
                lörem ipsum mytotropi grexit, krosk trehös. Rarade syde sakavis i krohyrad hemining. Divade. lörem ipsum mytotropi grexit, 
                krosk trehös. Rarade syde sakavis i krohyrad hemining. Divade.lörem ipsum mytotropi grexit, krosk trehös. Rarade syde sakavis
                 i krohyrad hemining. Divade. lörem ipsum mytotropi grexit, krosk trehös. Rarade syde sakavis i krohyrad hemining. Divade.
                  lörem ipsum mytotropi grexit, krosk trehös. Rarade syde sakavis i krohyrad hemining. Divade. lörem ipsum mytotropi grexit, 
                  krosk trehös. Rarade syde sakavis i krohyrad hemining. Divade.lörem ipsum mytotropi grexit, krosk trehös. Rarade syde sakavis
                   i krohyrad hemining. Divade. lörem ipsum mytotropi grexit, krosk trehös. Rarade syde sakavis i krohyrad hemining. Divade.
                   mytotropi grexit, krosk trehös. Rarade syde sakavis i krohyrad hemining. Divade. lörem ipsum mytotropi grexit, krosk trehös. 
                   Rarade syde sakavis i krohyrad hemining. Divade. lörem ipsum mytotropi grexit, krosk trehös. Rarade syde sakavis i krohyrad hemining. 
                   Divade.lörem ipsum mytotropi grexit, krosk trehös. Rarade syde sakavis i 
                krohyrad hemining. Divade. lörem ipsum mytotropi grexit, krosk trehös. Rarade syde sakavis i krohyrad hemining. Divade.
                </p>
                </div>

                <div className='sm-text-container'>
                <p className='sm-heading'>lorem ipsum</p>
                <p className='sm-content'>
                lörem ipsum mytotropi grexit, krosk trehös. Rarade syde sakavis i krohyrad hemining. Divade. lörem ipsum mytotropi grexit,
                 krosk trehös. Rarade syde sakavis i krohyrad hemining. Divade.lörem ipsum mytotropi grexit, krosk trehös. Rarade syde sakavis 
                i krohyrad hemining. Divade. lörem ipsum mytotropi grexit, krosk trehös. Rarade syde sakavis i krohyrad hemining. 
                Divade. lörem ipsum mytotropi grexit, krosk trehös. Rarade syde sakavis i krohyrad hemining. Divade. lörem ipsum 
                mytotropi grexit, krosk trehös. Rarade syde sakavis i krohyrad hemining. Divade.lörem ipsum mytotropi grexit, krosk 
                trehös. Rarade syde sakavis i krohyrad hemining. Divade. lörem ipsum mytotropi grexit, krosk trehös. Rarade syde sakavis i 
                krohyrad hemining. Divade. lörem ipsum mytotropi grexit, krosk trehös. Rarade syde sakavis i krohyrad hemining. Divade. 
                lörem ipsum mytotropi grexit, krosk trehös. Rarade syde sakavis i krohyrad hemining. Divade.lörem ipsum mytotropi grexit,
                 krosk trehös. Rarade syde sakavis i krohyrad hemining. Divade. lörem ipsum mytotropi grexit, krosk trehös. Rarade syde sakavis 
                 i krohyrad hemining. Divade. lörem ipsum mytotropi grexit, krosk trehös. Rarade syde sakavis 
                i krohyrad hemining. Divade. lörem ipsum mytotropi grexit, krosk trehös. Rarade syde sakavis i krohyrad hemin
                </p>
                </div>

            </div>
        </div>
        <Footer/>
    </div>
  )
}
